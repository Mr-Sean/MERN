import React, { useState, useEffect } from "react";
import axios from "axios";
    
const OneProduct = (props) => {
    
    const { _id } = props;
    const [productInfo, setProductInfo] = useState({});
    useEffect(() => {
        axios
            .get(`http://localhost:8000/api/product/${_id}`)
            .then((response) => {console.log(response.data)})
            .catch((err) => console.log(err));
    }, []);
    // console.log(_id); //not working

    return <h1>Display Product</h1>;
       
};
    
export default OneProduct;