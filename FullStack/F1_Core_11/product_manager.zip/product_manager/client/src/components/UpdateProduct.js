import React, { useState } from "react";
import axios from "axios";
    
const UpdateProduct = (props) => {
    return (
        <div>
            
        </div>
    )
}
    
export default UpdateProduct;